import * as React from 'react';
import {BloomRPC} from './components/BloomRPC';

export default function App() {
  return <BloomRPC />
}